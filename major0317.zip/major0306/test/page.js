function myFunction() {
  alert("Button clicked!");
  // JavaScript 代码，当点击按钮 "pop-btn" 时显示模态框 test 無用
  var modal = document.getElementById("myModal");
  modal.style.display = "block";

  var span = document.getElementsByClassName("close")[0];
  span.onclick = function () {
    modal.style.display = "none";
  };

  window.onclick = function (event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  };
}
