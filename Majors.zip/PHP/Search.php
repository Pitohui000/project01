<?php
// 建立數據庫連接
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連接是否成功
if ($conn->connect_error) {
    die("連接失敗：" . $conn->connect_error);
}
if (isset($_GET['q']) && !empty($_GET['q'])) {
// 接收表單提交的搜尋關鍵字
$searchKeyword = $_GET['q'];

// 構建SQL查詢
$sql = "SELECT * FROM songs WHERE song_name LIKE '%$searchKeyword%'";

// 執行查詢
$result = $conn->query($sql);

// 顯示查詢結果
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "ID: " . $row["song_id"]. " - Name: " . $row["song_name"]. "<br>";
    }
} else {
    echo "沒有匹配的結果";
}
}

// 關閉數據庫連接
$conn->close();
?>