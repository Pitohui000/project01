<?php
// 啟動 session
session_start();

// 建立數據庫連接
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連接是否成功
if ($conn->connect_error) {
    die("連接失敗：" . $conn->connect_error);
}

// 第一階段：執行搜尋
if (isset($_GET['searchSubmit'])) {
    // 接收表單提交的搜尋關鍵字
    $searchKeyword = $_GET['search'];

    // 構建 SQL 查詢
    $sql = "SELECT * FROM songs WHERE song_name LIKE '%$searchKeyword%'";

    // 執行查詢
    $result = $conn->query($sql);

    // 存儲搜尋結果到 session
    $_SESSION['searchResults'] = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
			echo "ID: " . $row["song_id"] . " - Name: " . $row["song_name"] . "<br>";
            $_SESSION['searchResults'][] = $row;
        }
    }
}

// 第二階段：選擇特定類型過濾
if (isset($_GET['filter'])) {
    // 接收表單提交的過濾類型
    $filterKeyword = $_GET['filter'];

    // 如果有搜尋結果，則進行過濾
    if (!empty($_SESSION['searchResults'])) {
        $filteredResults = [];
        foreach ($_SESSION['searchResults'] as $row) {
            if ($row['author'] == $filterKeyword) {
                $filteredResults[] = $row;
            }
        }

        // 顯示過濾結果
        if (!empty($filteredResults)) {
            foreach ($filteredResults as $row) {
                echo "ID: " . $row["song_id"] . " - Name: " . $row["song_name"] . "<br>";
            }
        } else {
            echo "沒有匹配的過濾結果";
        }
    } else {
        echo "沒有搜尋結果，無法進行過濾";
    }
}

// 關閉數據庫連接
$conn->close();
?>

<!-- 使用一個共同的表單 -->
<!--<form action="" method="GET">-->
    <!-- 第一階段的表單：執行搜尋 -->
    <!--
    <label for="search">搜尋歌曲：</label>
    <input type="text" name="search" id="search">
    <button type="submit" name="searchSubmit">執行搜尋</button>
	-->
    <!-- 第二階段：選擇特定類型過濾 -->
    <!--
    <button type="submit" name="filter" value="Rock">過濾 Rock</button>
    <button type="submit" name="filter" value="Pop">過濾 Pop</button>
    <button type="submit" name="filter" value="HipHop">過濾 Hip Hop</button>
	-->
    <!-- 其他選項... -->
	<!--
</form>-->