<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>桃園客家文化館導覽網站</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href ="CSS/Indexstyle.css?v=<?=time()?>">
	  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> <!--icon連結的css-->
    <script src="loading.js"></script>
</head>
<body>
   <!--加載-->
   <div class="loading-color">
     <div class="loading" id="fountainG">
	     <div id="fountainG_1" class="fountainG"></div>
	     <div id="fountainG_2" class="fountainG"></div>
	     <div id="fountainG_3" class="fountainG"></div>
	     <div id="fountainG_4" class="fountainG"></div>
	     <div id="fountainG_5" class="fountainG"></div>
	     <div id="fountainG_6" class="fountainG"></div>
	     <div id="fountainG_7" class="fountainG"></div>
	     <div id="fountainG_8" class="fountainG"></div>
     </div>
    </div>

    
    <header>
        <button class="menu" id="mobile-menu">&#9776;</button>
    <a href ="index.php"><h1>虛擬導覽網站</h1></a>
        <nav class="navbar">
            <ul class="menu-list">
                <li><a href="#">最新消息</a></li>
                <li><a href="#">虛擬導覽</a></li>
                <li><a href="#">園區資訊</a></li>
                <li><a href="Search.php">音樂作品查詢</a></li>
            </ul>
        </nav>
    </header>
    <div class="big"></div>
    
    <section class="news">
    <h2>客家文化館虛擬導覽</h2>
    <p><a href="vr.php">進入虛擬導覽</a></p>
    </section>
    <section class="slogan">
    <blockquote cite="#">"在思考製作時，<br>要去想環境的意義"</blockquote>
    </section>

    <section class="Map">
	<img src="https://github.com/Pitohui000/project01/blob/main/20210608163612.jpg?raw=true" alt ="gura">

    <div class="info">
    <h2>A! A! A! A!</h2>
    <p>好油喔 peko~~~<br>kuru kuru kuru</p>
    </div>
    </section>

    <section class="googlemap">
      <div class="container">
        <h2>相關資訊</h2>
        <div class="infos">
          <div class="left"> <b>桃園市客家文化館地址:</b> <span>325桃園市龍潭區中正路三林段500號</span> <b> 電話:03-4096682</b> 
            <b> 營業時間:<span>星期一：休息</span>
			<span>星期二～日：09:00–17:00</span></b> 
          </div>
          <div class="right"> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1810.2604679304209!2d121.23186715142786!3d24.84605159189432!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x34683da78b0cffcf%3A0xe2a2cbcf1cebbd89!2z5qGD5ZyS5biC5a6i5a625paH5YyW6aSo!5e0!3m2!1szh-TW!2stw!4v1698993887372!5m2!1szh-TW!2stw" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> </div>
        </div>
      </div>

    </section>

    <section class="newsletter">
        <p>歡迎提供建設性的建議</p>
        <form>
            <input type="文字" placeholder="請輸入文字" required>
            <button type="submit">送出</button>
        </form>
    </section>
    </main>
    <footer>
        Pitohui © All Rights Reserved. | Designed by GGlisten X Cadiis
    </footer>
</body>
</html>