<?php
// 啟動 session
session_start();

// 建立數據庫連接
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連接是否成功
if ($conn->connect_error) {
    die("連接失敗：" . $conn->connect_error);
}

// 每頁顯示的結果數量
$resultsPerPage = 5;

// 第一階段：執行搜尋
if (isset($_GET['searchSubmit'])) {
    // 檢查 "search" 是否存在
    $searchKeyword = isset($_GET['search']) ? $_GET['search'] : '';

    // 構建 SQL 查詢
    $sql = "SELECT * FROM songs WHERE song_name LIKE '%$searchKeyword%'";

    // 執行查詢
    $result = $conn->query($sql);

    // 存儲搜尋結果到 session
    $_SESSION['searchResults'] = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['searchResults'][] = $row;
        }

        // 顯示分頁結果
        $totalResults = count($_SESSION['searchResults']);
        $totalPages = ceil($totalResults / $resultsPerPage);

        // 當前頁碼
        $currentPage = isset($_GET['page']) ? $_GET['page'] : 1;
        $start = ($currentPage - 1) * $resultsPerPage;

        // 顯示當前頁的結果
        for ($i = $start; $i < $start + $resultsPerPage; $i++) {
            if (isset($_SESSION['searchResults'][$i])) {
                $row = $_SESSION['searchResults'][$i];
                echo "ID: " . $row["song_id"] . " - Name: " . $row["song_name"] . "<br>";
            }
        }

        // 顯示分頁連結
        for ($page = 1; $page <= $totalPages; $page++) {
            echo "<a href='?searchSubmit&page=$page'>$page</a> ";
        }
    } else {
        echo "沒有匹配的搜尋結果";
    }
}

// 第二階段：選擇特定類型過濾
if (isset($_GET['filter'])) {
    // 接收表單提交的過濾類型
    $filterKeyword = $_GET['filter'];

    // 如果有搜尋結果，則進行過濾
    if (!empty($_SESSION['searchResults'])) {
        $filteredResults = [];
        foreach ($_SESSION['searchResults'] as $row) {
            if ($row['author'] == $filterKeyword) {
                $filteredResults[] = $row;
            }
        }

        // 顯示分頁結果
        if (!empty($filteredResults)) {
            $totalResults = count($filteredResults);
            $totalPages = ceil($totalResults / $resultsPerPage);

            // 當前頁碼
            $currentPage = isset($_GET['page']) ? $_GET['page'] : 1;
            $start = ($currentPage - 1) * $resultsPerPage;

            // 顯示當前頁的結果
            for ($i = $start; $i < $start + $resultsPerPage; $i++) {
                if (isset($filteredResults[$i])) {
                    $row = $filteredResults[$i];
                    echo "ID: " . $row["song_id"] . " - Name: " . $row["song_name"] . "<br>";
                }
            }

            // 顯示分頁連結
            for ($page = 1; $page <= $totalPages; $page++) {
                echo "<a href='?filter=$filterKeyword&page=$page'>$page</a> ";
            }
        } else {
            echo "沒有匹配的過濾結果";
        }
    } else {
        echo "沒有搜尋結果，無法進行過濾";
    }
}

// 關閉數據庫連接
$conn->close();
?>
